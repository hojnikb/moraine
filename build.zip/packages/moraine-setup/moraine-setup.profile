# /etc/profile.d/moraine-setup.sh — offer the setup tool on first interactive login.
if [ "$(id -u)" = 0 ] && [ -t 0 ] && [ -t 1 ] && [ -n "$PS1" ] && command -v moraine-setup >/dev/null; then
	if [ ! -e /etc/moraine/setup.done ]; then
		printf '\n  Moraine is not configured yet.\n'
		printf '  Run the setup wizard now? [Y/n] '
		read -r _moraine_ans
		case $_moraine_ans in [nN]*) printf '  Later: run  moraine-setup\n\n' ;; *) moraine-setup ;; esac
		unset _moraine_ans
	else
		printf '  moraine-setup: configure GPU / LLM server    moraine-status: health\n\n'
	fi
fi
