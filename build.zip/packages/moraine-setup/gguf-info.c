/*
 * moraine-gguf-info: dump GGUF metadata as "key<TAB>value" lines.
 *
 * Scalars and strings are printed as-is (tabs/newlines flattened, long
 * strings truncated). Arrays of integers up to 1024 entries are printed as
 * a comma-separated list; other arrays as "<array:TYPE:N>". Large blobs
 * (tokenizer vocab, chat template) are summarised, never printed.
 *
 * usage: moraine-gguf-info FILE.gguf
 */
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { T_U8, T_I8, T_U16, T_I16, T_U32, T_I32, T_F32, T_BOOL, T_STR, T_ARR,
       T_U64, T_I64, T_F64 };

static FILE *f;

static void die(const char *m) { fprintf(stderr, "moraine-gguf-info: %s\n", m); exit(1); }
static void rd(void *p, size_t n) { if (fread(p, 1, n, f) != n) die("truncated file"); }
static uint32_t u32(void) { uint32_t v; rd(&v, 4); return v; }
static uint64_t u64(void) { uint64_t v; rd(&v, 8); return v; }

static char *str(size_t max, uint64_t *len_out)
{
	uint64_t n = u64();
	if (len_out) *len_out = n;
	if (n > (1u << 30)) die("string too long");
	size_t keep = n < max ? (size_t)n : max;
	char *s = malloc(keep + 1);
	if (!s) die("oom");
	rd(s, keep);
	s[keep] = 0;
	if (n > keep && fseeko(f, (off_t)(n - keep), SEEK_CUR)) die("seek failed");
	for (char *p = s; *p; p++)
		if (*p == '\t' || *p == '\n' || *p == '\r') *p = ' ';
	return s;
}

static const size_t tsize[] = { 1, 1, 2, 2, 4, 4, 4, 1, 0, 0, 8, 8, 8 };

static int64_t read_int(uint32_t t, int *ok)
{
	uint8_t b[8] = { 0 };
	*ok = 1;
	switch (t) {
	case T_U8:  rd(b, 1); return *(uint8_t *)b;
	case T_I8:  rd(b, 1); return *(int8_t *)b;
	case T_U16: rd(b, 2); return *(uint16_t *)b;
	case T_I16: rd(b, 2); return *(int16_t *)b;
	case T_U32: rd(b, 4); return *(uint32_t *)b;
	case T_I32: rd(b, 4); return *(int32_t *)b;
	case T_U64: rd(b, 8); return (int64_t)*(uint64_t *)b;
	case T_I64: rd(b, 8); return *(int64_t *)b;
	case T_BOOL: rd(b, 1); return b[0] != 0;
	}
	*ok = 0;
	return 0;
}

static void print_value(const char *key, uint32_t t)
{
	int ok;
	if (t == T_STR) {
		uint64_t len;
		int big = !strcmp(key, "tokenizer.chat_template");
		char *s = str(big ? 0 : 400, &len);
		if (big) printf("%s\t<string:%" PRIu64 ">\n", key, len);
		else printf("%s\t%s\n", key, s);
		free(s);
	} else if (t == T_F32) {
		float v; rd(&v, 4); printf("%s\t%g\n", key, v);
	} else if (t == T_F64) {
		double v; rd(&v, 8); printf("%s\t%g\n", key, v);
	} else if (t == T_ARR) {
		uint32_t et = u32();
		uint64_t n = u64();
		int is_int = et <= T_I32 && et != T_F32 ? 1 : (et == T_U64 || et == T_I64 || et == T_BOOL);
		if (is_int && n <= 1024) {
			printf("%s\t", key);
			for (uint64_t i = 0; i < n; i++) {
				int64_t v = read_int(et, &ok);
				printf(i ? ",%" PRId64 : "%" PRId64, v);
			}
			putchar('\n');
			return;
		}
		printf("%s\t<array:%u:%" PRIu64 ">\n", key, et, n);
		if (et == T_STR) {
			for (uint64_t i = 0; i < n; i++) {
				uint64_t l = u64();
				if (fseeko(f, (off_t)l, SEEK_CUR)) die("seek failed");
			}
		} else if (et < sizeof(tsize) / sizeof(tsize[0]) && tsize[et]) {
			if (fseeko(f, (off_t)(n * tsize[et]), SEEK_CUR)) die("seek failed");
		} else {
			die("nested arrays not supported");
		}
	} else {
		int64_t v = read_int(t, &ok);
		if (!ok) die("unknown value type");
		printf("%s\t%" PRId64 "\n", key, v);
	}
}

int main(int argc, char **argv)
{
	if (argc != 2) { fprintf(stderr, "usage: %s FILE.gguf\n", argv[0]); return 2; }
	f = fopen(argv[1], "rb");
	if (!f) { fprintf(stderr, "moraine-gguf-info: %s: %s\n", argv[1], strerror(errno)); return 1; }

	char magic[4];
	rd(magic, 4);
	if (memcmp(magic, "GGUF", 4)) die("not a GGUF file");
	uint32_t ver = u32();
	if (ver < 2) die("GGUF v1 not supported");
	uint64_t n_tensors = u64(), n_kv = u64();
	printf("gguf.version\t%u\ngguf.tensor_count\t%" PRIu64 "\n", ver, n_tensors);

	for (uint64_t i = 0; i < n_kv; i++) {
		char *key = str(256, NULL);
		uint32_t t = u32();
		print_value(key, t);
		free(key);
	}
	fclose(f);
	return 0;
}
