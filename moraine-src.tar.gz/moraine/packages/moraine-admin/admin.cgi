#!/bin/sh
# Moraine admin page. busybox httpd CGI, runs behind basic auth (user root).
# Pages: status (default), profile editor (?page=profile), model upload.
# Profile logic comes from moraine-setup itself (sourced as a library), so
# the page and the menu tool build profiles exactly the same way.

MS=/usr/sbin/moraine-setup
LOG=/var/log/llama-server.log
ACTLOG=/run/moraine/admin-action.log
MODELS=/srv/models
SELF=/cgi-bin/admin

# ---------------------------------------------------------------- lib ---
BC250_SETUP_LIB=1 . "$MS"
trap 'rm -rf "$TMP"' EXIT          # the library's trap would "clear" the terminal

esc() { sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g'; }
h() { printf %s "$1" | esc; }
urldecode() { printf '%b' "$(printf %s "$1" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')"; }
field() { urldecode "$(printf '%s' "$1" | tr '&' '\n' | sed -n "s/^$2=//p" | head -n1)"; }
mibs() { awk -v b="$1" 'BEGIN { printf "%d MiB", b / 1048576 }'; }
pct() { awk -v a="$1" -v b="$2" 'BEGIN { if (b > 0) printf "%d", a * 100 / b; else print 0 }'; }
sel() { [ "$1" = "$2" ] && echo ' selected'; }
chk() { [ "$1" = "$2" ] && echo ' checked'; }
# text that ends up in shell-sourced config files: no quoting/expansion chars
safe_text() { case $1 in *[\"\$\`\\\;\|\&\<\>\']*) return 1 ;; esac; return 0; }

reply() {   # status text
	printf 'HTTP/1.1 %s\r\nContent-Type: text/plain\r\nCache-Control: no-store\r\n\r\n%s\n' "$1" "$2"
	exit 0
}
redirect() {   # message [page]
	printf 'HTTP/1.1 303 See Other\r\nLocation: %s?%smsg=%s\r\nContent-Length: 0\r\n\r\n' \
		"$SELF" "${2:+page=$2&}" "$(printf %s "$1" | sed 's/ /+/g; s/[^A-Za-z0-9+._:,/-]//g')"
	exit 0
}

# ------------------------------------------------------- model upload ---
# The browser sends the file in 32 MiB slices (busybox httpd's
# Content-Length is 32-bit, and slices keep memory flat); each slice is
# written at its offset into NAME.part, which is renamed when complete.
upload_name() {   # sets n (reply exits on bad input, so no $(...) here)
	n=$(field "$QUERY_STRING" name); n=${n##*/}
	case $n in ''|*[!A-Za-z0-9._-]*) reply "400 Bad Request" "File name may only contain letters, digits, dot, dash and underscore." ;; esac
	case $n in *.gguf|*.GGUF) ;; *) reply "400 Bad Request" "Only .gguf files can be uploaded." ;; esac
}

if [ "$REQUEST_METHOD" = POST ]; then
	case $(field "$QUERY_STRING" action) in
	upload-init)
		upload_name; total=$(field "$QUERY_STRING" total)
		is_uint "$total" || reply "400 Bad Request" "bad size"
		[ -e "$MODELS/$n" ] && reply "409 Conflict" "$n already exists in /models."
		free=$(df -Pk "$MODELS" | awk 'NR==2 { print $4 }')
		[ $((total / 1024 + 1024)) -lt "${free:-0}" ] || reply "507 Insufficient Storage" "Not enough space: $((free / 1024)) MiB free, need $((total / 1048576)) MiB."
		mkdir -p "$MODELS"; : > "$MODELS/$n.part"; chmod 666 "$MODELS/$n.part"
		reply "200 OK" "ok" ;;
	upload-chunk)
		upload_name; off=$(field "$QUERY_STRING" offset)
		is_uint "$off" && [ $((off % 1048576)) -eq 0 ] || reply "400 Bad Request" "bad offset"
		[ -f "$MODELS/$n.part" ] || reply "409 Conflict" "upload not started"
		head -c "${CONTENT_LENGTH:-0}" | dd of="$MODELS/$n.part" bs=1M seek=$((off / 1048576)) conv=notrunc 2>/dev/null
		size=$(stat -c %s "$MODELS/$n.part")
		[ "$size" -ge $((off + ${CONTENT_LENGTH:-0})) ] || reply "500 Internal Server Error" "short write (disk full?)"
		reply "200 OK" "$size" ;;
	upload-done)
		upload_name; total=$(field "$QUERY_STRING" total)
		size=$(stat -c %s "$MODELS/$n.part" 2>/dev/null || echo 0)
		[ "$size" = "$total" ] || reply "409 Conflict" "size mismatch: have $size of $total bytes"
		mv -f "$MODELS/$n.part" "$MODELS/$n" && chmod 666 "$MODELS/$n"
		model_meta "$MODELS/$n" || { rm -f "$MODELS/$n"; reply "422 Unprocessable Entity" "Upload finished, but the file is not a valid GGUF model; deleted."; }
		reply "200 OK" "ok" ;;
	upload-abort)
		upload_name; rm -f "$MODELS/$n.part"; reply "200 OK" "ok" ;;
	esac
fi

# ------------------------------------------------------ JSON / text API ---
jstr() { printf %s "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r\t'; }
json_head() { printf 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n'; }
kv() { sed -n "s/^$2=//p" "$1" 2>/dev/null | head -n1; }

if [ "$REQUEST_METHOD" = GET ]; then
	case $(field "$QUERY_STRING" api) in
	progress)
		# model loading progress, written by llama-load-progress
		f=/run/moraine/load-progress
		json_head
		if [ -f "$f" ]; then
			now=$(date +%s); upd=$(kv "$f" updated); age=$((now - ${upd:-0}))
			dn=$(kv "$f" done)
			act=false; [ "$dn" != 1 ] && [ "$age" -lt 20 ] && act=true
			printf '{"active":%s,"done":%s,"rc":"%s","age":%s,"pct":%s,"phase":"%s","detail":"%s","model":"%s"}\n' \
				"$act" "$( [ "$dn" = 1 ] && echo true || echo false)" "$(jstr "$(kv "$f" rc)")" "$age" \
				"$(kv "$f" pct | tr -cd 0-9)" "$(jstr "$(kv "$f" phase)")" "$(jstr "$(kv "$f" detail)")" "$(jstr "$(kv "$f" model)")"
		else
			echo '{"active":false}'
		fi
		exit 0 ;;
	downloads)
		json_head
		printf '['
		sep=
		for st in /run/moraine/dl/*.state; do
			[ -f "$st" ] || continue
			nm=$(kv "$st" name)
			case $nm in
				*-00001-of-*.gguf) pat="${nm%-00001-of-*.gguf}-*-of-*.gguf" ;;
				*) pat=$nm ;;
			esac
			have=0
			for x in $MODELS/$pat $MODELS/$pat.part; do
				[ -f "$x" ] && have=$((have + $(stat -c %s "$x")))
			done
			printf '%s{"name":"%s","repo":"%s","total":%s,"have":%s,"status":"%s","message":"%s","started":%s}' "$sep" \
				"$(jstr "$nm")" "$(jstr "$(kv "$st" repo)")" "$(kv "$st" total | tr -cd 0-9)" "$have" \
				"$(jstr "$(kv "$st" status)")" "$(jstr "$(kv "$st" message)")" "$(kv "$st" started | tr -cd 0-9)"
			sep=,
		done
		echo ']'
		exit 0 ;;
	job)
		# output of a background tool run (bench / speedtest)
		j=$(field "$QUERY_STRING" name)
		case $j in bench|speedtest) ;; *) reply "400 Bad Request" "bad job" ;; esac
		printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\n\r\n'
		if [ -f "/run/moraine/$j.pid" ] && kill -0 "$(cat "/run/moraine/$j.pid")" 2>/dev/null; then echo "[running]"; else echo "[done]"; fi
		cat "/run/moraine/$j.txt" 2>/dev/null
		exit 0 ;;
	esac
fi

# -------------------------------------------------------- system page ---
render_system() {
	local mode mask fmap total vram gtt res fixed pts i f v gmin gmax thr rec se sh w tag
	render_head "System settings"
	[ -n "$msg" ] && printf '<div class="msg">%s</div>\n' "$(h "$msg")"
	mode=$(cu_mode_current); mask=",$(mask_current),"
	fmap=$(factory_map)
	cat <<EOT
<main>
<section class="card wide"><h2>GPU compute units</h2>
<form method="post" action="$SELF">
<input type="hidden" name="action" value="sys-cu">
<p><label style="display:inline"><input type="radio" name="cumode" value="0"$(chk "$mode" 0)> Stock 24 CU (safe)</label> &nbsp;
<label style="display:inline"><input type="radio" name="cumode" value="3"$(chk "$mode" 3)> 40 CU mode (all WGPs; more heat and power)</label></p>
<p class="hint">Running now: $(dmesg 2>/dev/null | grep -o 'active_cu_number [0-9]*' | tail -n1 | awk '{print $2}') CUs, loaded mode $(cat /sys/module/amdgpu/parameters/bc250_cc_write_mode 2>/dev/null). Changes apply after a reboot.</p>
$( [ -n "$fmap" ] && printf '<pre>Factory layout (this boot):\n%s</pre>' "$(printf '%s' "$fmap" | esc)")
<details$( [ "$mask" != ",," ] && echo ' open')><summary>Disable individual WGPs (boards whose unlocked units are unstable)</summary>
<p class="hint">Tick WGPs to DISABLE (1 WGP = 2 CUs). WGP 0-2 are stock, 3-4 are unlocked by 40 CU mode.</p><table><tr><th></th>
EOT
	w=0; while [ $w -lt 5 ]; do printf '<th>WGP %s</th>' "$w"; w=$((w + 1)); done; echo '</tr>'
	for se in 0 1; do for sh in 0 1; do
		printf '<tr><th>SE%s SH%s</th>' "$se" "$sh"
		w=0; while [ $w -lt 5 ]; do
			tag="$se.$sh.$w"
			case $mask in *",$tag,"*) c=' checked' ;; *) c= ;; esac
			printf '<td><input type="checkbox" name="wgp" value="%s"%s></td>' "$tag" "$c"
			w=$((w + 1))
		done
		echo '</tr>'
	done; done
	cat <<EOT
</table></details>
<div class="row"><button class="p">Save (reboot to apply)</button></div></form></section>

<section class="card wide"><h2>GPU clocks &amp; voltage (governor)</h2>
<form method="post" action="$SELF"><input type="hidden" name="action" value="sys-gov">
<p class="hint">Voltage/frequency points; the governor interpolates between them. A single point means a fixed clock, like the stock board. Voltage must not drop as frequency rises; above 1000 mV is risky.</p>
<table><tr><th>Frequency (MHz)</th><th>Voltage (mV)</th></tr>
EOT
	pts=$(gov_points)
	i=0
	for line in $(printf '%s\n' "$pts" | tr ' ' ':'); do
		f=${line%:*}; v=${line#*:}
		printf '<tr><td><input type="number" name="f%s" value="%s" min="350" max="2500"></td><td><input type="number" name="v%s" value="%s" min="650" max="1150"></td></tr>\n' "$i" "$f" "$i" "$v"
		i=$((i + 1))
	done
	n=$((i + 3)); [ $n -gt 12 ] && n=12
	while [ $i -lt $n ]; do
		printf '<tr><td><input type="number" name="f%s" min="350" max="2500" placeholder="add"></td><td><input type="number" name="v%s" min="650" max="1150"></td></tr>\n' "$i" "$i"
		i=$((i + 1))
	done
	gmin=$(gov_get frequency-range min); gmax=$(gov_get frequency-range max)
	thr=$(gov_get temperature throttling); rec=$(gov_get temperature throttling_recovery)
	cat <<EOT
</table><p class="hint">Clear both fields of a row to remove that point.</p>
<div class="grid">
<div><label>Min clock (MHz)</label><input type="number" name="gmin" value="${gmin:-1500}"></div>
<div><label>Max clock (MHz)</label><input type="number" name="gmax" value="${gmax:-1500}"></div>
<div><label>Throttle at (&deg;C)</label><input type="number" name="thr" value="${thr:-85}"></div>
<div><label>Recover at (&deg;C)</label><input type="number" name="rec" value="${rec:-75}"></div>
</div>
<div class="row"><button class="p">Save &amp; apply</button></div></form></section>
EOT
	total=$(awk '/^MemTotal:/ { print int($2/1024) }' /proc/meminfo)
	res=$(conf_get "$GTT_CONF" GTT_RESERVE_MB); fixed=$(conf_get "$GTT_CONF" GTT_MB)
	dev=$(gpu_dev)
	vram=$(( $(cat "$dev/mem_info_vram_total" 2>/dev/null || echo 0) / 1048576 ))
	gtt=$(( $(cat "$dev/mem_info_gtt_total" 2>/dev/null || echo 0) / 1048576 ))
	cat <<EOT
<section class="card"><h2>GPU memory pool (GTT)</h2>
<p class="hint">System RAM: $total MiB &middot; VRAM carve-out: $vram MiB &middot; GTT pool now: $gtt MiB. The pool is system RAM the GPU may use; the rest stays for Linux and llama-server's CPU-side buffers.</p>
<form method="post" action="$SELF"><input type="hidden" name="action" value="sys-gtt">
<label><input type="radio" name="gttmode" value="reserve"$( [ -z "$fixed" ] && echo ' checked')> RAM minus a reserve</label>
<label><input type="radio" name="gttmode" value="fixed"$( [ -n "$fixed" ] && echo ' checked')> Fixed GTT size</label>
<label>MiB (reserve 256-8192, or fixed size)</label><input type="number" name="gttval" value="${fixed:-${res:-1024}}">
<div class="row"><button class="p">Save (reboot to apply)</button></div></form></section>

<section class="card"><h2>Password</h2>
<form method="post" action="$SELF"><input type="hidden" name="action" value="sys-passwd">
<p class="hint">Root password for SSH, the console and this page.</p>
<label>New password</label><input type="password" name="pw1" autocomplete="new-password">
<label>Repeat</label><input type="password" name="pw2" autocomplete="new-password">
<div class="row"><button class="p">Change password</button></div></form></section>

<section class="card wide"><h2>Tools</h2>
<div class="row">
<form class="i" method="post" action="$SELF"><input type="hidden" name="action" value="bench"><button>Benchmark active profile</button></form>
<form class="i" method="post" action="$SELF"><input type="hidden" name="action" value="speedtest"><button>Drive read-speed test</button></form>

</div>
<p class="hint">Benchmark: llama-bench, prompt 512 + generate 128 tokens, with the active profile's KV / flash-attention / ubatch settings. llama-server is stopped while it runs.</p>
<h2 style="margin-top:12px">Benchmark output</h2><pre id="job_bench">$(cat /run/moraine/bench.txt 2>/dev/null | esc)</pre>
<h2 style="margin-top:12px">Drive speed output</h2><pre id="job_speedtest">$(cat /run/moraine/speedtest.txt 2>/dev/null | esc)</pre>
</section>
</main>
<script>
async function poll(j) {
	try {
		const t = await (await fetch('?api=job&name=' + j)).text();
		const run = t.startsWith('[running]');
		document.getElementById('job_' + j).textContent = t.replace(/^\[(running|done)\]\n?/, '') + (run ? '\n... running' : '');
		if (run) setTimeout(() => poll(j), 2000);
	} catch (e) {}
}
poll('bench'); poll('speedtest');
</script></body></html>
EOT
	exit 0
}

# ------------------------------------------------- Hugging Face page ---
render_hf() {
	render_head "Hugging Face"
	[ -n "$msg" ] && printf '<div class="msg">%s</div>\n' "$(h "$msg")"
	cat <<EOT
<main>
<section class="card wide"><h2>Download from Hugging Face (preview)</h2>
<p class="hint">Search runs in your browser against the Hugging Face API; the download itself runs on this box, straight to /models (busybox wget, ~1-2 MB RAM, resumable). Free space: $(df -Pm "$MODELS" 2>/dev/null | awk 'NR==2 { print $4 " MiB" }'). The box needs internet access.</p>
<div class="row"><input type="text" id="q" placeholder="search, e.g. qwen3 8b, gemma 3, llama 3.2" style="flex:1" onkeydown="if(event.key==='Enter')search()">
<button class="p" onclick="search()">Search</button></div>
<div id="results"></div><div id="files"></div>
</section>
<section class="card wide"><h2>Downloads</h2><div id="dls"><p class="hint">No downloads.</p></div>
<form class="i" method="post" action="$SELF"><input type="hidden" name="action" value="hf-clear"><button>Clear finished</button></form></section>
<section class="card wide"><h2>Access token (optional)</h2>
<form method="post" action="$SELF"><input type="hidden" name="action" value="hf-token">
<p class="hint">Needed only for gated or private models. Stored root-only on the box and used only for downloads. $( [ -s /etc/moraine/hf-token ] && echo '<b>A token is saved.</b>' || echo 'No token saved.') Leave empty and save to remove.</p>
<input type="password" name="token" placeholder="hf_..." autocomplete="off"> <div class="row"><button>Save token</button></div></form></section>
</main>
EOT
	cat <<'EOT'
<form id="dlf" method="post" action="/cgi-bin/admin" style="display:none">
<input type="hidden" name="action" value="hf-download"><input name="repo"><input name="file"><input name="total"></form>
<script>
const H = 'https://huggingface.co';
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mib = b => Math.round(b / 1048576).toLocaleString() + ' MiB';
async function search() {
	const q = document.getElementById('q').value.trim(); if (!q) return;
	const r = document.getElementById('results'); r.innerHTML = '<p class="hint">Searching...</p>';
	document.getElementById('files').innerHTML = '';
	try {
		const list = await (await fetch(H + '/api/models?filter=gguf&sort=downloads&limit=25&search=' + encodeURIComponent(q))).json();
		if (!list.length) { r.innerHTML = '<p class="hint">Nothing found.</p>'; return; }
		r.innerHTML = '<table><tr><th>Repository</th><th>Downloads</th><th></th></tr>' + list.map(m =>
			'<tr><td>' + esc(m.id) + '</td><td>' + (m.downloads || 0).toLocaleString() + '</td><td><button onclick="files(\'' +
			esc(m.id) + '\')">Files</button> <a href="' + H + '/' + esc(m.id) + '" target="_blank">page</a></td></tr>').join('') + '</table>';
	} catch (e) { r.innerHTML = '<p class="bad">Search failed: ' + esc(e.message) + ' (is your browser online?)</p>'; }
}
async function files(repo) {
	const f = document.getElementById('files'); f.innerHTML = '<p class="hint">Loading file list...</p>';
	try {
		const t = await (await fetch(H + '/api/models/' + repo + '/tree/main?recursive=true')).json();
		if (!Array.isArray(t)) throw new Error(t.error || 'no access (gated model? save a token and download anyway)');
		const g = t.filter(x => x.type === 'file' && /\.gguf$/i.test(x.path) && !/mmproj/i.test(x.path));
		const groups = {};
		for (const x of g) {
			const m = x.path.match(/^(.*)-(\d{5})-of-(\d{5})\.gguf$/i);
			const key = m ? m[1] + '-00001-of-' + m[3] + '.gguf' : x.path;
			(groups[key] = groups[key] || { size: 0, parts: 0 }).size += (x.lfs ? x.lfs.size : x.size) || 0;
			groups[key].parts++;
		}
		const mm = t.filter(x => x.type === 'file' && /mmproj.*\.gguf$/i.test(x.path));
		const rows = Object.keys(groups).sort().map(k =>
			'<tr><td>' + esc(k) + (groups[k].parts > 1 ? ' <span class="hint">(' + groups[k].parts + ' parts)</span>' : '') +
			'</td><td>' + mib(groups[k].size) + '</td><td><button class="p" onclick="dl(\'' + esc(repo) + '\',\'' + esc(k) + '\',' + groups[k].size + ')">Download</button></td></tr>');
		for (const x of mm) rows.push('<tr><td>' + esc(x.path) + ' <span class="hint">(vision projector)</span></td><td>' +
			mib((x.lfs ? x.lfs.size : x.size) || 0) + '</td><td><button onclick="dl(\'' + esc(repo) + '\',\'' + esc(x.path) + '\',' + ((x.lfs ? x.lfs.size : x.size) || 0) + ')">Download</button></td></tr>');
		f.innerHTML = '<h2 style="margin-top:14px">' + esc(repo) + '</h2>' + (rows.length ? '<table><tr><th>File</th><th>Size</th><th></th></tr>' + rows.join('') + '</table>' : '<p class="hint">No GGUF files in this repository.</p>') +
			'<p class="hint">Pick a quant that fits: the file size is roughly the GPU memory the weights need, plus KV cache and compute buffers.</p>';
	} catch (e) { f.innerHTML = '<p class="bad">' + esc(e.message) + '</p>'; }
}
function dl(repo, file, size) {
	if (!confirm('Download ' + file + ' (' + mib(size) + ') to /models?')) return;
	const f = document.getElementById('dlf');
	f.repo.value = repo; f.file.value = file; f.total.value = size; f.submit();
}
const last = {};
async function dls() {
	try {
		const a = await (await fetch('?api=downloads')).json();
		const d = document.getElementById('dls');
		if (!a.length) { d.innerHTML = '<p class="hint">No downloads.</p>'; }
		else d.innerHTML = '<table>' + a.map(x => {
			const pct = x.total ? Math.min(100, x.have * 100 / x.total) : 0;
			const now = Date.now() / 1000, p = last[x.name];
			let rate = '';
			if (p && x.status === 'downloading' && now > p.t) {
				const r = (x.have - p.h) / (now - p.t);
				if (r > 0) rate = (r / 1048576).toFixed(1) + ' MiB/s, ~' + Math.round((x.total - x.have) / r) + ' s left';
			}
			last[x.name] = { h: x.have, t: now };
			return '<tr><td><b>' + esc(x.name) + '</b><br><span class="hint">' + esc(x.repo) + '</span></td><td style="width:45%"><progress value="' + pct +
				'" max="100"></progress><br><span class="hint">' + mib(x.have) + ' / ' + mib(x.total) + ' ' + rate + '</span></td><td class="' +
				(x.status === 'done' ? 'ok' : x.status === 'downloading' ? 'warn' : 'bad') + '">' + esc(x.status) + '<br><span class="hint">' + esc(x.message) + '</span></td><td>' +
				(x.status === 'downloading' ? '<form class="i" method="post" action="/cgi-bin/admin"><input type="hidden" name="action" value="hf-cancel"><input type="hidden" name="name" value="' + esc(x.name) + '"><button>Cancel</button></form>' : '') + '</td></tr>';
		}).join('') + '</table>';
	} catch (e) {}
	setTimeout(dls, 2000);
}
dls();
</script></body></html>
EOT
	exit 0
}

# ----------------------------------------------------- profile editor ---
# Fill M_* / A_* from a posted form.
form_to_state() {   # body
	local b=$1 i v t
	P_NAME=$(field "$b" name)
	M_PATH=$(field "$b" model)
	M_KV=$(field "$b" kv); M_CTX=$(field "$b" ctx)
	[ "$M_CTX" = custom ] && M_CTX=$(field "$b" ctx_custom)
	M_UB=$(field "$b" ub); M_NP=$(field "$b" np); M_LM=$(field "$b" lm); M_FA=$(field "$b" fa)
	M_REASON=$(field "$b" reason); M_CTXCP=$(field "$b" ctxcp)
	M_PORT=$(field "$b" port); M_ALIAS=$(field "$b" alias); M_APIKEY=$(field "$b" apikey)
	M_TEMP=$(field "$b" temp); M_EXTRA=$(field "$b" extra); M_WEBUI=$(field "$b" webui)
	M_MMPROJ=; [ "$(field "$b" vision)" = on ] && M_MMPROJ=$(field "$b" mmproj)
	for i in $(adv_ids); do adv_set "$i" "$(field "$b" "adv_$i")"; done
}

# Same rules as the moraine-setup wizard. Prints the first problem.
validate_state() {
	VERR=
	profile_valid_name "$P_NAME" || { VERR="Profile name: letters, digits, dot, dash, underscore (max 40)."; return; }
	case $M_PATH in "$MODELS"/*.gguf|"$MODELS"/*.GGUF|/models/*.gguf|/media/*.gguf|/mnt/*.gguf) ;; *) VERR="Choose a model."; return ;; esac
	[ -f "$M_PATH" ] || { VERR="Model file not found: $M_PATH"; return; }
	case $M_KV in f16/f16|q8_0/q8_0|q8_0/q5_1|q8_0/q4_0|q4_0/q4_0) ;; *) VERR="Invalid KV cache type."; return ;; esac
	[ "$M_CTX" = auto ] || { is_uint "$M_CTX" && [ "$M_CTX" -ge 512 ]; } || { VERR="Context: a number of at least 512, or Auto."; return; }
	is_uint "$M_UB" && [ "$M_UB" -ge 32 ] || { VERR="Micro-batch must be a number of at least 32."; return; }
	is_uint "$M_NP" && [ "$M_NP" -ge 1 ] && [ "$M_NP" -le 16 ] || { VERR="Parallel slots: 1-16."; return; }
	case $M_LM in dio|none|mmap) ;; *) VERR="Invalid load mode."; return ;; esac
	case $M_FA in on|off|auto) ;; *) VERR="Invalid flash attention setting."; return ;; esac
	[ "$M_FA" != on ] && [ "${M_KV#*/}" != f16 ] && M_FA=on
	case $M_REASON in auto|on|off) ;; *) VERR="Invalid reasoning setting."; return ;; esac
	[ -z "$M_CTXCP" ] || is_uint "$M_CTXCP" || { VERR="Context checkpoints must be a number."; return; }
	is_uint "$M_PORT" && [ "$M_PORT" -ge 1 ] && [ "$M_PORT" -le 65535 ] || { VERR="Invalid port."; return; }
	case $M_ALIAS in *[!A-Za-z0-9._:-]*) VERR="Alias: letters, digits, . _ : - only."; return ;; esac
	[ -z "$M_TEMP" ] || echo "$M_TEMP" | grep -qE '^[0-9]+(\.[0-9]+)?$' || { VERR="Temperature must be a number."; return; }
	safe_text "$M_APIKEY" || { VERR="API key: no quotes, \$, backslash or ; | & < >."; return; }
	safe_text "$M_EXTRA" || { VERR="Extra args: no quotes, \$, backslash or ; | & < >."; return; }
	case $M_WEBUI in on|off) ;; *) M_WEBUI=off ;; esac
	[ -z "$M_MMPROJ" ] || [ -f "$M_MMPROJ" ] || M_MMPROJ=
	local i v t
	for i in $(adv_ids); do
		v=$(adv_get "$i"); [ -n "$v" ] || continue
		t=$(adv_field "$i" 2)
		case $t in
			bool) [ "$v" = on ] || adv_set "$i" "" ;;
			tri)  case $v in on|off) ;; *) adv_set "$i" "" ;; esac ;;
			int)  echo "$v" | grep -qE '^-?[0-9]+$' || { VERR="$(adv_field "$i" 5): whole number."; return; } ;;
			num)  echo "$v" | grep -qE '^-?[0-9]+(\.[0-9]+)?$' || { VERR="$(adv_field "$i" 5): number."; return; } ;;
			choice) adv_field "$i" 4 | tr ' ' '\n' | cut -d= -f1 | grep -qxF -- "$v" || adv_set "$i" "" ;;
		esac
	done
}

save_profile() {   # activate(yes/no)
	mkdir -p "$PROFILE_DIR"
	state_save "$(profile_file "$P_NAME")"
	if [ "$1" = yes ]; then
		( "$MS" cli activate "$P_NAME" > "$ACTLOG" 2>&1 </dev/null & )
		redirect "Profile $P_NAME saved; loading it now - watch the status"
	fi
	if [ "$(profile_active)" = "$P_NAME" ]; then
		redirect "Profile $P_NAME saved. It is the active profile: Activate it again to apply the changes"
	fi
	redirect "Profile $P_NAME saved"
}

render_head() {   # title
	printf 'Content-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\n\r\n'
	cat <<EOF
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>$(h "$1") - Moraine</title>
<style>
:root{--bg:#f6f7f9;--fg:#1d2330;--card:#fff;--mut:#667085;--line:#e3e6ea;--acc:#2f6fdf;--ok:#12805c;--warn:#b25e00;--off:#9aa1ab;--bad:#c0362c}
@media (prefers-color-scheme:dark){:root{--bg:#12151b;--fg:#e6e9ef;--card:#1b2029;--mut:#98a1b0;--line:#2b3240;--acc:#6ea0ff;--ok:#3ccf91;--warn:#f0a847;--off:#6b7380;--bad:#ff6b5e}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
header{padding:18px 20px 6px;max-width:1000px;margin:auto}h1{margin:0;font-size:22px}h1 small{color:var(--mut);font-weight:400;font-size:14px}
h1 a{color:inherit;text-decoration:none}.quip{color:var(--mut);font-style:italic;margin:4px 0 0}
main{max-width:1000px;margin:auto;padding:8px 20px 30px;display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(310px,1fr))}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}.wide{grid-column:1/-1}
h2{margin:0 0 10px;font-size:15px;text-transform:uppercase;letter-spacing:.04em;color:var(--mut)}
table{width:100%;border-collapse:collapse}td,th{padding:5px 4px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}th{color:var(--mut);font-weight:500}
.ok{color:var(--ok)}.warn{color:var(--warn)}.off{color:var(--off)}.bad{color:var(--bad)}
.bar{height:8px;background:var(--line);border-radius:4px;overflow:hidden;margin-top:3px}.bar i{display:block;height:100%;background:var(--acc)}
button,.btn{font:inherit;padding:6px 12px;border-radius:7px;border:1px solid var(--line);background:var(--bg);color:var(--fg);cursor:pointer;text-decoration:none;display:inline-block}
button.p,.btn.p{background:var(--acc);border-color:var(--acc);color:#fff}button:hover,.btn:hover{filter:brightness(1.08)}
form.i{display:inline}.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center}
.msg{max-width:960px;margin:10px auto 0;padding:10px 14px;border-radius:8px;background:var(--card);border:1px solid var(--acc)}
.err{border-color:var(--bad)}
pre{margin:0;max-height:320px;overflow:auto;font:12px/1.4 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap}
a{color:var(--acc)}input,select{font:inherit;padding:5px 7px;border-radius:6px;border:1px solid var(--line);background:var(--bg);color:var(--fg);max-width:100%}
input[type=text],input[type=number],select{width:100%}label{display:block;font-size:13px;color:var(--mut);margin-top:8px}
.grid{display:grid;gap:4px 14px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}
.hint{font-size:12.5px;color:var(--mut);margin:2px 0 0}details{margin-top:6px}summary{cursor:pointer;color:var(--acc)}
.adv{border-top:1px solid var(--line);padding:8px 0}.adv b{font-weight:600}
progress{width:100%;height:14px}
</style></head><body>
<header><h1><a href="$SELF">Moraine</a> <small>$(h "$(. /etc/os-release 2>/dev/null; echo "$PRETTY_NAME")") &middot; $(hostname | esc)</small></h1>
<p class="quip">$(h "$(cat /run/moraine/quip 2>/dev/null)")</p>
<nav class="row"><a class="btn" href="$SELF">Status &amp; profiles</a><a class="btn" href="$SELF?page=profile">New profile</a><a class="btn" href="$SELF?page=system">System settings</a><a class="btn" href="$SELF?page=hf">Hugging Face</a></nav></header>
EOF
}

render_editor() {   # orig-name error
	local orig=$1 err=$2 budget model mm cmp avail ctx kv fit max note p size i t v cand
	[ -n "$M_PATH" ] && [ -f "$M_PATH" ] && model_meta "$M_PATH"
	budget=$(gpu_budget_mib)
	render_head "${P_NAME:-New profile}"
	[ -n "$err" ] && printf '<div class="msg err">%s</div>\n' "$(h "$err")"
	cat <<EOF
<main><section class="card wide"><h2>$( [ -n "$orig" ] && echo "Edit profile" || echo "New profile")</h2>
<form method="post" action="$SELF?page=profile" id="pf">
<input type="hidden" name="orig" value="$(h "$orig")">
<input type="hidden" name="prev_model" value="$(h "$M_PATH")">
<div class="grid">
<div><label>Profile name</label><input type="text" name="name" value="$(h "$P_NAME")" maxlength="40" pattern="[A-Za-z0-9._-]+" required></div>
<div style="grid-column:span 2"><label>Model</label><select name="model" onchange="this.form.elements['do'][0].click()">
<option value="">- choose a model -</option>
EOF
	list_models | while IFS="$(printf '\t')" read -r p size; do
		printf '<option value="%s"%s>%s  (%s MiB, %s)</option>\n' "$(h "$p")" "$(sel "$p" "$M_PATH")" \
			"$(h "$(model_label "$p")")" "$size" "$(h "$(place_of "$p")")"
	done
	cat <<EOF
</select><p class="hint">Models in /models and on USB drives. Upload new ones on the main page.</p></div>
</div>
EOF
	if [ -n "$M_PATH" ] && [ -f "$M_PATH" ]; then
		model=$(model_size_mib "$M_PATH")
		cand=$(find "$(dirname "$M_PATH")" -maxdepth 1 -iname '*mmproj*.gguf' 2>/dev/null | head -n1)
		mm=0; [ -n "$M_MMPROJ" ] && [ "$A_mmcpu" != on ] && mm=$(model_size_mib "$M_MMPROJ")
		cmp=$(compute_mib)
		avail=$((budget - model - mm - cmp - 384))
		max=${MI_CTX:-131072}
		note=$(kv_mib 1024 "${M_KV%/*}" "${M_KV#*/}" | cut -d' ' -f2-)
		cat <<EOF
<p class="hint"><b>$(h "${MI_NAME:-$(model_label "$M_PATH")}")</b> &middot; $(h "$MI_ARCH") &middot; $MI_LAYERS layers &middot; trained context ${MI_CTX:-?}$( [ -n "$note" ] && printf ' &middot; %s' "$(h "$note")")</p>
EOF
		if [ -n "$cand" ]; then
			cat <<EOF
<label><input type="checkbox" name="vision" value="on"$(chk "$M_MMPROJ" "$cand")> Image input (vision projector $(h "$(basename "$cand")"), costs $(model_size_mib "$cand") MiB of GPU memory)</label>
<input type="hidden" name="mmproj" value="$(h "$cand")">
EOF
		fi
		cat <<EOF
<div class="grid">
<div><label>KV cache precision</label><select name="kv">
<option value="f16/f16"$(sel "$M_KV" f16/f16)>f16 / f16 - full (100%)</option>
<option value="q8_0/q8_0"$(sel "$M_KV" q8_0/q8_0)>q8_0 / q8_0 - recommended (53%)</option>
<option value="q8_0/q5_1"$(sel "$M_KV" q8_0/q5_1)>q8_0 / q5_1 (45%)</option>
<option value="q8_0/q4_0"$(sel "$M_KV" q8_0/q4_0)>q8_0 / q4_0 (41%)</option>
<option value="q4_0/q4_0"$(sel "$M_KV" q4_0/q4_0)>q4_0 / q4_0 - smallest (28%)</option>
</select><p class="hint">Biggest memory cost after the weights. Quantized V needs flash attention.</p></div>
<div><label>Context length (tokens)</label><select name="ctx">
<option value="auto"$(sel "$M_CTX" auto)>Auto - largest that fits</option>
EOF
		found=
		for ctx in 2048 4096 8192 16384 32768 49152 65536 98304 131072 196608 262144; do
			[ "$ctx" -gt "$max" ] && break
			kv=$(kv_mib "$ctx" "${M_KV%/*}" "${M_KV#*/}" | cut -d' ' -f1)
			if [ "$A_nkvo" = on ] || [ "$kv" -le "$avail" ]; then fit="fits"; else fit="TOO BIG"; fi
			[ "$ctx" = "$M_CTX" ] && found=1
			printf '<option value="%s"%s>%s - KV %s MiB - %s</option>\n' "$ctx" "$(sel "$ctx" "$M_CTX")" "$ctx" "$kv" "$fit"
		done
		custom=; [ -z "$found" ] && [ "$M_CTX" != auto ] && custom=$M_CTX
		cat <<EOF
<option value="custom"$( [ -n "$custom" ] && echo ' selected')>Custom...</option>
</select><input type="number" name="ctx_custom" min="512" placeholder="custom size" value="$custom" style="margin-top:4px"></div>
<div><label>Micro-batch (ubatch)</label><input type="number" name="ub" min="32" value="$(h "$M_UB")"><p class="hint">Compute buffer size. 256 saves memory, 1024+ speeds up long prompts.</p></div>
<div><label>Parallel slots</label><input type="number" name="np" min="1" max="16" value="$(h "$M_NP")"><p class="hint">Requests served at once; context is shared.</p></div>
<div><label>Load mode</label><select name="lm">
<option value="dio"$(sel "$M_LM" dio)>dio - O_DIRECT, best on NVMe</option>
<option value="none"$(sel "$M_LM" none)>none - plain reads, best on USB sticks</option>
<option value="mmap"$(sel "$M_LM" mmap)>mmap - memory-mapped</option>
</select>$(on_usb "$M_PATH" && echo '<p class="hint">This model is on a USB drive: "none" is recommended.</p>')</div>
<div><label>Flash attention</label><select name="fa">
<option value="on"$(sel "$M_FA" on)>on</option><option value="auto"$(sel "$M_FA" auto)>auto</option><option value="off"$(sel "$M_FA" off)>off</option>
</select></div>
<div><label>Reasoning (thinking models)</label><select name="reason">
<option value="auto"$(sel "$M_REASON" auto)>model default</option><option value="on"$(sel "$M_REASON" on)>always think</option><option value="off"$(sel "$M_REASON" off)>never think</option>
</select></div>
EOF
		if [ -n "$MI_SWA" ] || [ -n "$MI_FAI" ] || [ -n "$MI_SSM" ] || echo "$MI_KVH" | grep -q ','; then
			cat <<EOF
<div><label>Context checkpoints</label><input type="number" name="ctxcp" min="0" value="$(h "$M_CTXCP")" placeholder="32 (default)"><p class="hint">Sliding-window/hybrid model: checkpoints live in system RAM. Fewer = less RAM.</p></div>
EOF
		fi
		cat <<EOF
</div>
<h2 style="margin-top:16px">Server</h2><div class="grid">
<div><label>Port</label><input type="number" name="port" min="1" max="65535" value="$(h "$M_PORT")"></div>
<div><label>Alias (model name for clients)</label><input type="text" name="alias" value="$(h "${M_ALIAS:-$(model_label "$M_PATH")}")"></div>
<div><label>API key (empty = none)</label><input type="text" name="apikey" value="$(h "$M_APIKEY")" autocomplete="off"></div>
<div><label>Temperature (empty = model default)</label><input type="text" name="temp" value="$(h "$M_TEMP")"></div>
<div><label>llama.cpp web chat UI</label><select name="webui"><option value="off"$(sel "$M_WEBUI" off)>off - API only</option><option value="on"$(sel "$M_WEBUI" on)>on (~3 MB RAM while used, no GPU memory)</option></select></div>
<div><label>Extra args (advanced)</label><input type="text" name="extra" value="$(h "$M_EXTRA")"></div>
</div>
<details$( [ -n "$(adv_args)" ] && echo ' open')><summary>Advanced llama.cpp options ($(for i in $(adv_ids); do [ -n "$(adv_get "$i")" ] && echo x; done | wc -l) changed)</summary>
EOF
		for i in $(adv_ids); do
			adv_relevant "$i" || continue
			t=$(adv_field "$i" 2); v=$(adv_get "$i")
			printf '<div class="adv"><b>%s</b> &middot; <span class="hint">GPU memory: %s</span><p class="hint">%s</p>' \
				"$(h "$(adv_field "$i" 5)")" "$(h "$(adv_field "$i" 6)")" "$(h "$(adv_field "$i" 7)")"
			case $t in
			bool) printf '<select name="adv_%s"><option value="">off (default)</option><option value="on"%s>on</option></select>' "$i" "$(sel "$v" on)" ;;
			tri)  printf '<select name="adv_%s"><option value="">llama.cpp default</option><option value="on"%s>on</option><option value="off"%s>off</option></select>' "$i" "$(sel "$v" on)" "$(sel "$v" off)" ;;
			choice)
				printf '<select name="adv_%s"><option value="">llama.cpp default</option>' "$i"
				for c in $(adv_field "$i" 4); do printf '<option value="%s"%s>%s</option>' "${c%%=*}" "$(sel "$v" "${c%%=*}")" "${c#*=}"; done
				printf '</select>' ;;
			*) printf '<input type="text" name="adv_%s" value="%s" placeholder="default">' "$i" "$(h "$v")" ;;
			esac
			printf '</div>\n'
		done
		echo '</details>'
		# summary estimate
		if [ "$M_CTX" = auto ]; then kvs="auto"; tot="?"
		else
			kv=$(kv_mib "$M_CTX" "${M_KV%/*}" "${M_KV#*/}" | cut -d' ' -f1)
			if [ "$A_nkvo" = on ]; then tot=$((model + mm + cmp)); kvs="$kv MiB (system RAM)"
			else tot=$((model + mm + kv + cmp)); kvs="$kv MiB"; fi
		fi
		cls=ok; [ "$tot" != "?" ] && [ "$tot" -gt $((budget - 384)) ] && cls=bad
		cat <<EOF
<h2 style="margin-top:16px">Memory estimate</h2>
<table><tr><th>Weights</th><td>$model MiB</td></tr>
$( [ "$mm" -gt 0 ] && printf '<tr><th>Vision projector</th><td>%s MiB</td></tr>' "$mm")
<tr><th>KV cache</th><td>$(h "$kvs")</td></tr>
<tr><th>Compute buffers</th><td>~$cmp MiB</td></tr>
<tr><th>Total / GPU memory</th><td class="$cls"><b>$tot MiB</b> of $budget MiB$( [ "$cls" = bad ] && echo ' - will not fit')</td></tr></table>
<p class="hint">Estimates; the llama-server log shows the real allocations. Press "Update estimate" after changing settings.</p>
EOF
	fi
	cat <<EOF
<div class="row" style="margin-top:14px">
<button name="do" value="estimate">Update estimate</button>
<button name="do" value="save">Save</button>
<button name="do" value="activate" class="p">Save &amp; activate</button>
<a class="btn" href="$SELF">Cancel</a>
</div></form></section></main></body></html>
EOF
	exit 0
}

page=$(field "$QUERY_STRING" page)
if [ "$page" = profile ]; then
	if [ "$REQUEST_METHOD" = POST ]; then
		body=$(head -c "${CONTENT_LENGTH:-0}" 2>/dev/null)
		orig=$(field "$body" orig)
		state_load /none
		prev=$M_PATH
		form_to_state "$body"
		do=$(field "$body" do)
		# newly chosen model: sensible defaults for it
		if [ "$M_PATH" != "$(field "$body" prev_model)" ] && [ -f "$M_PATH" ]; then
			if on_usb "$M_PATH"; then M_LM=none; else M_LM=dio; fi
			M_ALIAS=$(model_label "$M_PATH"); M_MMPROJ=
		fi
		if [ "$do" = estimate ] || [ -z "$do" ]; then
			render_editor "$orig" ""
		fi
		validate_state
		[ -n "$VERR" ] && render_editor "$orig" "$VERR"
		if [ -n "$orig" ] && [ "$orig" != "$P_NAME" ] && [ -f "$(profile_file "$P_NAME")" ]; then
			render_editor "$orig" "A profile named $P_NAME already exists."
		fi
		if [ -z "$orig" ] && [ -f "$(profile_file "$P_NAME")" ]; then
			render_editor "$orig" "A profile named $P_NAME already exists. Edit it instead, or pick another name."
		fi
		if [ -n "$orig" ] && [ "$orig" != "$P_NAME" ]; then
			rm -f "$(profile_file "$orig")"
			[ "$(profile_active)" = "$orig" ] && echo "$P_NAME" > "$ACTIVE_FILE"
		fi
		[ -z "$M_ALIAS" ] && M_ALIAS=$(model_label "$M_PATH")
		save_profile "$( [ "$do" = activate ] && echo yes || echo no)"
	fi
	name=$(field "$QUERY_STRING" name)
	if [ -n "$name" ] && profile_valid_name "$name" && [ -f "$(profile_file "$name")" ]; then
		state_load "$(profile_file "$name")"
		render_editor "$name" ""
	fi
	state_load /none
	render_editor "" ""
fi

# -------------------------------------------------------- main actions ---
if [ "$REQUEST_METHOD" = POST ]; then
	body=$(head -c "${CONTENT_LENGTH:-0}" 2>/dev/null)
	action=$(field "$body" action)
	prof=$(field "$body" profile)
	mkdir -p /run/moraine
	case $action in
	activate)
		profile_valid_name "$prof" || redirect "Invalid profile name"
		( "$MS" cli activate "$prof" > "$ACTLOG" 2>&1 </dev/null & )
		redirect "Activating profile $prof - watch the status below" ;;
	delete)
		profile_valid_name "$prof" && [ -f "$(profile_file "$prof")" ] || redirect "No such profile"
		rm -f "$(profile_file "$prof")"
		[ "$(profile_active)" = "$prof" ] && rm -f "$ACTIVE_FILE"
		redirect "Profile $prof deleted (the model file was not touched)" ;;
	start)
		( "$MS" cli start > "$ACTLOG" 2>&1 </dev/null & )
		redirect "Starting llama-server" ;;
	stop)
		"$MS" cli stop > "$ACTLOG" 2>&1
		redirect "llama-server stopped, model unloaded" ;;
	boot-on)  "$MS" cli boot on;  redirect "llama-server will start at boot" ;;
	boot-off) "$MS" cli boot off; redirect "llama-server will not start at boot" ;;
	hf-download)
		repo=$(field "$body" repo); file=$(field "$body" file); total=$(field "$body" total)
		case $repo in */*) ;; *) redirect "Invalid repository" hf ;; esac
		case "$repo$file" in *[!A-Za-z0-9._/-]*|*..*) redirect "Invalid repository or file name" hf ;; esac
		case $file in *.gguf|*.GGUF) ;; *) redirect "Only .gguf files" hf ;; esac
		is_uint "$total" || total=0
		free=$(df -Pk "$MODELS" | awk 'NR==2 { print $4 }')
		[ "$total" -gt 0 ] && [ $((total / 1024 + 1024)) -ge "${free:-0}" ] && redirect "Not enough space in /models: $((${free:-0} / 1024)) MiB free, need $((total / 1048576)) MiB" hf
		setsid /usr/libexec/moraine/moraine-hf-download "$repo" "$file" "$total" </dev/null >/dev/null 2>&1 &
		redirect "Downloading ${file##*/} from $repo" hf ;;
	hf-cancel)
		nm=$(field "$body" name); nm=${nm##*/}
		st=/run/moraine/dl/$nm.state
		[ -f "$st" ] || redirect "No such download" hf
		pid=$(kv "$st" pid)
		[ -f "/run/moraine/dl/$nm.wget" ] && kill "$(cat "/run/moraine/dl/$nm.wget")" 2>/dev/null
		[ -n "$pid" ] && kill "$pid" 2>/dev/null
		redirect "Download of $nm cancelled" hf ;;
	hf-clear)
		for st in /run/moraine/dl/*.state; do
			[ -f "$st" ] || continue
			case $(kv "$st" status) in downloading) ;; *) rm -f "$st" ;; esac
		done
		redirect "Finished downloads cleared from the list" hf ;;
	hf-token)
		tok=$(field "$body" token)
		if [ -z "$tok" ]; then rm -f /etc/moraine/hf-token; redirect "Hugging Face token removed" hf; fi
		case $tok in *[!A-Za-z0-9_-]*) redirect "That does not look like a Hugging Face token" hf ;; esac
		umask 077; printf '%s\n' "$tok" > /etc/moraine/hf-token
		redirect "Hugging Face token saved (used for gated and private models)" hf ;;
	sys-cu)
		m=$(field "$body" cumode)
		case $m in 0|3) ;; *) redirect "Invalid CU mode" system ;; esac
		if grep -q '^options amdgpu .*bc250_cc_write_mode=' "$CU_CONF" 2>/dev/null; then
			sed -i "s/bc250_cc_write_mode=[0-9]*/bc250_cc_write_mode=$m/" "$CU_CONF"
		else
			echo "options amdgpu bc250_cc_write_mode=$m" >> "$CU_CONF"
		fi
		list=$(printf '%s' "$body" | tr '&' '\n' | sed -n 's/^wgp=//p' | sed 's/%2E/./g; s/%2e/./g' | grep -E '^[01]\.[01]\.[0-4]$' | tr '\n' ',' | sed 's/,$//')
		for sa in 0.0 0.1 1.0 1.1; do
			[ "$(echo "$list" | tr ',' '\n' | grep -c "^$sa\.")" -ge 5 ] && redirect "Refusing to disable all 5 WGPs of shader array $sa" system
		done
		if [ -n "$list" ]; then
			printf '# Written by the Moraine admin page. Format SE.SH.WGP (1 WGP = 2 CUs).\noptions amdgpu disable_cu=%s\n' "$list" > "$MASK_CONF"
		else
			rm -f "$MASK_CONF"
		fi
		redirect "Saved: $( [ "$m" = 3 ] && echo '40 CU mode' || echo 'stock 24 CU')$( [ -n "$list" ] && echo ", disabled WGPs $list"). Reboot to apply" system ;;
	sys-gov)
		pts=$TMP/pts; : > "$pts"
		i=0
		while [ $i -lt 12 ]; do
			f=$(field "$body" "f$i"); v=$(field "$body" "v$i")
			if [ -n "$f$v" ]; then
				is_uint "$f" && is_uint "$v" || redirect "Governor: frequency and voltage must be whole numbers" system
				echo "$f $v" >> "$pts"
			fi
			i=$((i + 1))
		done
		sort -n "$pts" -o "$pts"
		mn=$(field "$body" gmin); mx=$(field "$body" gmax); thr=$(field "$body" thr); rec=$(field "$body" rec)
		is_uint "$mn" && is_uint "$mx" && [ "$mn" -le "$mx" ] || redirect "Governor: need min <= max clock" system
		is_uint "$thr" && is_uint "$rec" && [ "$rec" -lt "$thr" ] && [ "$thr" -le 100 ] || redirect "Governor: need recover < throttle <= 100" system
		err=$(gov_validate "$pts" | head -n1)
		[ -n "$err" ] && redirect "Governor: $err" system
		top=$(tail -n1 "$pts" | cut -d' ' -f1)
		[ "$mx" -gt "$top" ] && redirect "Governor: max clock $mx MHz is above the highest point ($top MHz)" system
		gov_write "$pts" "$mn" "$mx" "$thr" "$rec"
		if gov_restart; then redirect "Governor settings saved and applied" system
		else cp -p "$GOV_CONF.bak" "$GOV_CONF"; gov_restart; redirect "The governor did not start with these settings; previous settings restored" system; fi ;;
	sys-gtt)
		gm=$(field "$body" gttmode); gv=$(field "$body" gttval)
		total=$(awk '/^MemTotal:/ { print int($2/1024) }' /proc/meminfo)
		is_uint "$gv" || redirect "GTT: enter a number of MiB" system
		if [ "$gm" = fixed ]; then
			[ "$gv" -ge 1024 ] && [ "$gv" -le $((total - 256)) ] || redirect "GTT: fixed size must be 1024-$((total - 256)) MiB" system
			printf '# Written by the Moraine admin page.\nGTT_RESERVE_MB="1024"\nGTT_MB="%s"\n' "$gv" > "$GTT_CONF"
		else
			[ "$gv" -ge 256 ] && [ "$gv" -le 8192 ] || redirect "GTT: reserve must be 256-8192 MiB" system
			printf '# Written by the Moraine admin page.\nGTT_RESERVE_MB="%s"\nGTT_MB=""\n' "$gv" > "$GTT_CONF"
		fi
		redirect "GTT pool setting saved. Reboot to apply" system ;;
	sys-passwd)
		a=$(field "$body" pw1); b=$(field "$body" pw2)
		[ "$a" = "$b" ] || redirect "The passwords did not match" system
		[ ${#a} -ge 4 ] || redirect "Use at least 4 characters" system
		case $a in *[[:cntrl:]]*|*:*) redirect "Password may not contain colons or control characters" system ;; esac
		if printf 'root:%s\n' "$a" | chpasswd -c sha512 >/dev/null 2>&1; then
			rm -f /etc/moraine/default-password
			moraine-admin-passwd "$a"
			redirect "Password changed for SSH, console and this page. Your browser will ask for it again" system
		fi
		redirect "Changing the password failed" system ;;
	bench|speedtest)
		if [ -f "/run/moraine/$action.pid" ] && kill -0 "$(cat "/run/moraine/$action.pid")" 2>/dev/null; then
			redirect "$action is already running" system
		fi
		( "$MS" cli "$action" > "/run/moraine/$action.txt" 2>&1 </dev/null & echo $! > "/run/moraine/$action.pid" )
		redirect "$( [ "$action" = bench ] && echo 'Benchmark started (1-3 minutes; the server is stopped meanwhile)' || echo 'Drive speed test started')" system ;;
	reboot)
		( sleep 2; reboot ) >/dev/null 2>&1 </dev/null &
		redirect "Rebooting - this page comes back in about a minute" ;;
	*) redirect "Unknown action" ;;
	esac
fi

# ---------------------------------------------------------- status page --
msg=$(field "$QUERY_STRING" msg)
case $page in
	system) render_system ;;
	hf) render_hf ;;
esac
eval "$("$MS" cli state 2>/dev/null)"          # mode active running boot
port=$(conf_get "$LLAMA_CONF" LLAMA_PORT); : "${port:=8080}"
host=${HTTP_HOST%%:*}; : "${host:=$(hostname)}"
healthy=no
wget -q -T 2 -O /dev/null "http://127.0.0.1:$port/health" 2>/dev/null && healthy=yes

dev=$(gpu_dev)
if [ -n "$dev" ]; then
	vu=$(cat "$dev/mem_info_vram_used" 2>/dev/null || echo 0); vt=$(cat "$dev/mem_info_vram_total" 2>/dev/null || echo 0)
	gu=$(cat "$dev/mem_info_gtt_used" 2>/dev/null || echo 0);  gt=$(cat "$dev/mem_info_gtt_total" 2>/dev/null || echo 0)
	temp=
	for hw in "$dev"/hwmon/hwmon*; do
		[ -r "$hw/temp1_input" ] && temp="$(($(cat "$hw/temp1_input") / 1000)) &deg;C"
	done
fi
cumode=$(cat /sys/module/amdgpu/parameters/bc250_cc_write_mode 2>/dev/null)
cus=$(dmesg 2>/dev/null | grep -o 'active_cu_number [0-9]*' | tail -n1 | awk '{print $2}')
memavail=$(awk '/^MemAvailable:/ { printf "%d MiB", $2 / 1024 }' /proc/meminfo)
memtotal=$(awk '/^MemTotal:/ { printf "%d MiB", $2 / 1024 }' /proc/meminfo)
uptime=$(awk '{ d = int($1 / 86400); hh = int($1 % 86400 / 3600); m = int($1 % 3600 / 60);
	printf "%s%dh %dm", (d ? d "d " : ""), hh, m }' /proc/uptime)
loadavg=$(cut -d' ' -f1-3 /proc/loadavg)
starterr=$(cat /run/moraine/llama-start-error 2>/dev/null)
diskfree=$(df -Pm "$MODELS" 2>/dev/null | awk 'NR==2 { print $4 " MiB" }')

if [ "$running" = yes ] && [ "$healthy" = yes ]; then srv="running"; cls=ok
elif [ "$running" = yes ]; then srv="starting / loading model"; cls=warn
else srv="stopped"; cls=off; fi

render_head "$(hostname)"
[ -n "$msg" ] && printf '<div class="msg">%s</div>\n' "$(h "$msg")"
cat <<EOF
<main>
<section class="card wide" id="loadcard" style="display:none"><h2>Loading model <span id="loadmodel"></span></h2>
<progress id="loadbar" value="0" max="100"></progress>
<p class="hint" id="loadtxt"></p></section>
<section class="card"><h2>LLM server</h2><table>
<tr><th>Status</th><td class="$cls">$srv</td></tr>
<tr><th>Active profile</th><td>$(h "${active:-none}")</td></tr>
<tr><th>Start at boot</th><td>$boot</td></tr>
<tr><th>API</th><td><code>http://$(h "$host"):$port/v1</code></td></tr>
<tr><th>Web chat</th><td><a href="http://$(h "$host"):$port/" target="_blank">llama.cpp web UI</a> (if enabled in the profile)</td></tr>
EOF
[ -n "$starterr" ] && printf '<tr><th>Last failure</th><td class="warn">%s</td></tr>\n' "$(h "$starterr")"
cat <<EOF
</table><div class="row">
<form class="i" method="post"><input type="hidden" name="action" value="$( [ "$running" = yes ] && echo stop || echo start )">
<button class="p">$( [ "$running" = yes ] && echo 'Stop &amp; unload model' || echo 'Start' )</button></form>
<form class="i" method="post"><input type="hidden" name="action" value="$( [ "$boot" = yes ] && echo boot-off || echo boot-on )">
<button>$( [ "$boot" = yes ] && echo "Don't start at boot" || echo 'Start at boot' )</button></form>
</div></section>

<section class="card"><h2>GPU &amp; memory</h2><table>
EOF
if [ -n "$dev" ]; then
	cat <<EOF
<tr><th>VRAM</th><td>$(mibs "$vu") / $(mibs "$vt")<div class="bar"><i style="width:$(pct "$vu" "$vt")%"></i></div></td></tr>
<tr><th>GTT pool</th><td>$(mibs "$gu") / $(mibs "$gt")<div class="bar"><i style="width:$(pct "$gu" "$gt")%"></i></div></td></tr>
<tr><th>Temperature</th><td>${temp:-?}</td></tr>
<tr><th>Compute units</th><td>${cus:-?} (mode ${cumode:-?})</td></tr>
EOF
else
	echo '<tr><td colspan="2" class="warn">BC-250 GPU not found</td></tr>'
fi
cat <<EOF
<tr><th>System RAM</th><td>$memavail free of $memtotal</td></tr>
<tr><th>Uptime / load</th><td>$uptime &middot; $loadavg</td></tr>
</table></section>

<section class="card wide"><h2>Profiles</h2>
<table><tr><th></th><th>Profile</th><th>Model</th><th>Context</th><th>KV</th><th></th></tr>
EOF
"$MS" cli list 2>/dev/null | while IFS='|' read -r p model ctx kv act; do
	mark=; [ "$act" = 1 ] && mark='&#9679;'
	printf '<tr><td class="ok">%s</td><td><b>%s</b></td><td>%s</td><td>%s</td><td>%s</td><td style="white-space:nowrap">' \
		"$mark" "$(h "$p")" "$(h "$model")" "$ctx" "$kv"
	printf '<form class="i" method="post"><input type="hidden" name="action" value="activate"><input type="hidden" name="profile" value="%s"><button%s>%s</button></form> ' \
		"$(h "$p")" "$( [ "$act" = 1 ] || echo ' class="p"' )" "$( [ "$act" = 1 ] && echo Reload || echo Activate )"
	printf '<a class="btn" href="%s?page=profile&amp;name=%s">Edit</a> ' "$SELF" "$(h "$p")"
	printf '<form class="i" method="post" onsubmit="return confirm(%s)"><input type="hidden" name="action" value="delete"><input type="hidden" name="profile" value="%s"><button>Delete</button></form></td></tr>\n' \
		"'Delete profile $(h "$p")? The model file is kept.'" "$(h "$p")"
done
cat <<EOF
</table>
<div class="row"><a class="btn p" href="$SELF?page=profile">New profile</a></div>
</section>

<section class="card wide"><h2>Upload a model</h2>
<div class="row"><input type="file" id="upfile" accept=".gguf"><button class="p" id="upbtn" onclick="upload()">Upload to /models</button>
<span class="hint">Free space: ${diskfree:-?}. The file goes straight to disk in 32 MiB pieces; keep this page open until it finishes.</span></div>
<progress id="upbar" value="0" max="100" style="display:none"></progress><p class="hint" id="upmsg"></p>
</section>

<section class="card wide"><h2>llama-server log (last 40 lines)</h2><pre>$(tail -n 40 "$LOG" 2>/dev/null | esc)</pre></section>

<section class="card wide"><h2>System</h2>
<div class="row"><form class="i" method="post" onsubmit="return confirm('Reboot the box?')"><input type="hidden" name="action" value="reboot"><button>Reboot</button></form></div>
<p class="hint">This page refreshes every 15 seconds (paused while uploading). Everything here is also in <code>moraine-setup</code> and <code>moraine-status</code>.</p>
</section>
</main>
EOF
cat <<'EOF'
<script>
let busy = false, loading = false;
setTimeout(function refresh() {
	if (busy || loading) { setTimeout(refresh, 15000); return; }
	location.replace(location.pathname);
}, 15000);

// model loading progress (boot, moraine-setup or this page): same data as
// the console progress bar, from /run/moraine/load-progress
async function progress() {
	try {
		const p = await (await fetch('?api=progress')).json();
		const card = document.getElementById('loadcard');
		if (p.active) {
			loading = true; card.style.display = '';
			document.getElementById('loadbar').value = p.pct || 0;
			document.getElementById('loadmodel').textContent = p.model || '';
			document.getElementById('loadtxt').textContent = (p.pct || 0) + '%  ' + p.phase + ': ' + p.detail;
		} else if (loading) {
			loading = false;
			location.replace(location.pathname + '?msg=' + encodeURIComponent(p.rc === '0' ? 'Model loaded: ' + p.model : 'Loading ' + p.model + ' ended: ' + p.phase + ' ' + p.detail));
			return;
		}
	} catch (e) {}
	setTimeout(progress, loading ? 1000 : 3000);
}
progress();

async function upload() {
	const f = document.getElementById('upfile').files[0];
	const bar = document.getElementById('upbar'), msg = document.getElementById('upmsg');
	if (!f) { alert('Choose a .gguf file first.'); return; }
	if (!/^[A-Za-z0-9._-]+\.gguf$/i.test(f.name)) { alert('File name may only contain letters, digits, dot, dash and underscore, and must end in .gguf.'); return; }
	const q = 'name=' + encodeURIComponent(f.name) + '&total=' + f.size;
	busy = true; document.getElementById('upbtn').disabled = true;
	bar.style.display = ''; bar.value = 0;
	const CH = 32 * 1024 * 1024, t0 = Date.now();
	try {
		let r = await fetch('?action=upload-init&' + q, { method: 'POST' });
		if (!r.ok) throw new Error(await r.text());
		for (let off = 0; off < f.size; off += CH) {
			const end = Math.min(off + CH, f.size);
			r = await fetch('?action=upload-chunk&' + q + '&offset=' + off,
				{ method: 'POST', body: f.slice(off, end), headers: { 'Content-Type': 'application/octet-stream' } });
			if (!r.ok) throw new Error(await r.text());
			bar.value = end * 100 / f.size;
			const s = (Date.now() - t0) / 1000, rate = end / s;
			msg.textContent = Math.round(end / 1048576) + ' / ' + Math.round(f.size / 1048576) + ' MiB, ' +
				(rate / 1048576).toFixed(1) + ' MiB/s, ~' + Math.round((f.size - end) / rate) + ' s left';
		}
		r = await fetch('?action=upload-done&' + q, { method: 'POST' });
		if (!r.ok) throw new Error(await r.text());
		location.href = location.pathname + '?msg=' + encodeURIComponent('Uploaded ' + f.name + ' - create a profile for it with New profile');
	} catch (e) {
		fetch('?action=upload-abort&' + q, { method: 'POST' });
		msg.textContent = 'Upload failed: ' + e.message;
		busy = false; document.getElementById('upbtn').disabled = false;
	}
}
</script></body></html>
EOF
